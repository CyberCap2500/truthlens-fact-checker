import React from 'react';
import AnalyzeClaimForm from './components/AnalyzeClaimForm';
import AnalyzeImageForm from './components/AnalyzeImageForm';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>🔍 TruthLens</h1>
        <h3>AI-Powered Fact Checking</h3>
        <p>Detect misinformation in text and images using advanced AI technology</p>
      </header>
      
      <main className="App-main">
        <AnalyzeClaimForm />
        <hr className="section-divider" />
        <AnalyzeImageForm />
      </main>
      
      <footer className="App-footer">
        <p>Powered by Google Generative AI & Fact-Check APIs</p>
      </footer>
    </div>
  );
}

export default App;
