import React, { useState } from 'react';
import axios from 'axios';
import './AnalyzeClaimForm.css';

function AnalyzeClaimForm() {
  const [statement, setStatement] = useState('');
  const [factcheckApiKey, setFactcheckApiKey] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!statement.trim()) {
      setError('Please enter a statement to analyze');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await axios.post('http://localhost:8000/analyze_claim/', {
        statement: statement.trim(),
        factcheck_api_key: factcheckApiKey || null
      });
      
      setResult(response.data);
    } catch (err) {
      console.error('Error analyzing claim:', err);
      setError(
        err.response?.data?.detail || 
        'Failed to analyze claim. Please check your API configuration and try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (classification) => {
    if (!classification) return '⚠️';
    if (classification.toLowerCase().includes('true')) return '✅';
    if (classification.toLowerCase().includes('false') || classification.toLowerCase().includes('misleading')) {
      return '❌';
    }
    return '⚠️';
  };

  const getStatusClass = (classification) => {
    if (!classification) return 'status-unknown';
    if (classification.toLowerCase().includes('true')) return 'status-true';
    if (classification.toLowerCase().includes('false') || classification.toLowerCase().includes('misleading')) {
      return 'status-false';
    }
    return 'status-misleading';
  };

  return (
    <div className="analyze-claim-form">
      <h2>📝 Analyze Claim or Statement</h2>
      <p className="form-description">
        Enter any claim, news headline, or statement you'd like to analyze for potential misinformation
      </p>
      
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="statement">Statement to Analyze</label>
          <textarea
            id="statement"
            rows="5"
            value={statement}
            onChange={(e) => setStatement(e.target.value)}
            placeholder="Enter a claim, news headline, or statement..."
            disabled={loading}
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="factcheck-key">Fact-Check API Key (Optional)</label>
          <input
            id="factcheck-key"
            type="password"
            value={factcheckApiKey}
            onChange={(e) => setFactcheckApiKey(e.target.value)}
            placeholder="Enter your Google Fact-Check API key for additional verification"
            disabled={loading}
          />
          <small>Without this key, only AI analysis will be performed</small>
        </div>
        
        <button type="submit" disabled={loading} className="submit-button">
          {loading ? '🔍 Analyzing...' : '🔍 Check Truth'}
        </button>
      </form>

      {error && (
        <div className="error-message">
          <h4>❌ Error</h4>
          <p>{error}</p>
        </div>
      )}

      {result && (
        <div className="result-container">
          <h3>📊 Analysis Results</h3>
          
          {/* AI Analysis Results */}
          {result.ai_analysis && (
            <div className="analysis-section">
              <h4>🤖 AI Analysis</h4>
              <div className="analysis-card">
                <div className="classification-result">
                  <div className="status-icon">
                    {getStatusIcon(result.ai_analysis.classification)}
                  </div>
                  <div className={`status-text ${getStatusClass(result.ai_analysis.classification)}`}>
                    {result.ai_analysis.classification || 'Unknown'}
                  </div>
                </div>
                
                {result.ai_analysis.confidence_score && (
                  <div className="confidence-score">
                    <label>Confidence Score:</label>
                    <div className="score-bar">
                      <div 
                        className="score-fill" 
                        style={{ width: `${result.ai_analysis.confidence_score}%` }}
                      ></div>
                    </div>
                    <span className="score-text">{result.ai_analysis.confidence_score}%</span>
                  </div>
                )}
                
                {result.ai_analysis.explanation && (
                  <div className="explanation">
                    <label>Explanation:</label>
                    <p>{result.ai_analysis.explanation}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Fact-Check Results */}
          {result.fact_check && (
            <div className="analysis-section">
              <h4>🔗 Fact-Check Sources</h4>
              {result.fact_check.claims && result.fact_check.claims.length > 0 ? (
                <div className="fact-check-results">
                  <p>Found {result.fact_check.claims.length} related fact-check articles:</p>
                  {result.fact_check.claims.map((claim, index) => (
                    <div key={index} className="fact-check-item">
                      <div className="claim-text">
                        <strong>Claim:</strong> {claim.text || 'No claim text available'}
                      </div>
                      {claim.claimReview && claim.claimReview.length > 0 && (
                        <div className="claim-review">
                          {claim.claimReview.map((review, reviewIndex) => (
                            <div key={reviewIndex} className="review-item">
                              <p><strong>Publisher:</strong> {review.publisher?.name || 'Unknown'}</p>
                              <p><strong>Rating:</strong> {review.textualRating || 'Not rated'}</p>
                              {review.url && (
                                <p>
                                  <strong>Source:</strong>{' '}
                                  <a href={review.url} target="_blank" rel="noopener noreferrer">
                                    {review.title || 'View Article'}
                                  </a>
                                </p>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="no-fact-check">
                  <p>{result.fact_check.message || 'No matching fact-check articles found.'}</p>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default AnalyzeClaimForm;
