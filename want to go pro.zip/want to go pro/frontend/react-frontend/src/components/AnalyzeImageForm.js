import React, { useState } from 'react';
import axios from 'axios';
import './AnalyzeImageForm.css';

function AnalyzeImageForm() {
  const [image, setImage] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        setError('Please select a valid image file');
        return;
      }

      // Validate file size (10MB limit)
      if (file.size > 10 * 1024 * 1024) {
        setError('Image file too large. Please select an image smaller than 10MB');
        return;
      }

      setImage(file);
      setError(null);
      setResult(null);

      // Create preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!image) {
      setError('Please select an image file');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const formData = new FormData();
      formData.append('file', image);

      const response = await axios.post('http://localhost:8000/analyze_image/', formData, {
        headers: { 
          'Content-Type': 'multipart/form-data' 
        }
      });

      setResult(response.data);
    } catch (err) {
      console.error('Error analyzing image:', err);
      setError(
        err.response?.data?.detail || 
        'Failed to analyze image. Please check your API configuration and try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setImage(null);
    setImagePreview(null);
    setResult(null);
    setError(null);
  };

  return (
    <div className="analyze-image-form">
      <h2>🖼️ Analyze Image</h2>
      <p className="form-description">
        Upload an image to detect potential manipulation, misleading visuals, and fake content using AI vision technology
      </p>
      
      <form onSubmit={handleSubmit}>
        <div className="file-upload-section">
          <div className="file-input-wrapper">
            <input
              type="file"
              id="image-upload"
              onChange={handleFileChange}
              accept="image/*"
              disabled={loading}
            />
            <label htmlFor="image-upload" className="file-input-label">
              <div className="upload-icon">📁</div>
              <div className="upload-text">
                <strong>Choose an image file</strong>
                <span>or drag and drop here</span>
              </div>
              <div className="upload-formats">
                PNG, JPG, JPEG, GIF, WEBP (Max 10MB)
              </div>
            </label>
          </div>
        </div>

        {imagePreview && (
          <div className="image-preview">
            <h4>📸 Selected Image</h4>
            <img src={imagePreview} alt="Preview" className="preview-image" />
            <div className="image-info">
              <p><strong>File:</strong> {image.name}</p>
              <p><strong>Size:</strong> {(image.size / 1024 / 1024).toFixed(2)} MB</p>
              <p><strong>Type:</strong> {image.type}</p>
            </div>
          </div>
        )}

        <div className="form-actions">
          <button 
            type="submit" 
            disabled={loading || !image} 
            className="submit-button"
          >
            {loading ? '🔍 Analyzing...' : '🔍 Analyze Image'}
          </button>
          
          {image && (
            <button 
              type="button" 
              onClick={handleReset}
              className="reset-button"
              disabled={loading}
            >
              🗑️ Clear
            </button>
          )}
        </div>
      </form>

      {error && (
        <div className="error-message">
          <h4>❌ Error</h4>
          <p>{error}</p>
        </div>
      )}

      {result && (
        <div className="result-container">
          <h3>🔍 Image Analysis Results</h3>
          
          <div className="analysis-section">
            <div className="analysis-card">
              <div className="result-header">
                <h4>📋 Analysis Report</h4>
                <div className="file-details">
                  <p><strong>File:</strong> {result.filename}</p>
                  <p><strong>Type:</strong> {result.content_type}</p>
                  <p><strong>Size:</strong> {(result.file_size / 1024 / 1024).toFixed(2)} MB</p>
                </div>
              </div>
              
              <div className="analysis-content">
                {result.image_analysis ? (
                  <div className="analysis-text">
                    {result.image_analysis}
                  </div>
                ) : (
                  <p className="no-analysis">No analysis result available</p>
                )}
              </div>
            </div>
            
            <div className="pro-tip">
              <h5>💡 Pro Tip</h5>
              <p>
                For additional verification, try a reverse image search using Google Images or TinEye 
                to find where else this image has been used.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default AnalyzeImageForm;
