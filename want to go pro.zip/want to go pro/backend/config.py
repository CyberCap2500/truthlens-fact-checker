# TruthLens API Configuration
import os

# API Keys
GEMINI_API_KEY = "AIzaSyAtuk2Bq5TxAh2VhkXNmdvLs2T496tBCHM"
FACTCHECK_API_KEY = "AIzaSyCNUSWp2HJkmvZl8ZTBlSCGUKRvM9MEALk"

# Environment variables (fallback)
if not GEMINI_API_KEY:
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if not FACTCHECK_API_KEY:
    FACTCHECK_API_KEY = os.getenv("FACTCHECK_API_KEY")
