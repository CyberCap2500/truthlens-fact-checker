from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from gen_ai.TruthLens import (
    configure_genai,
    enhanced_analyze_statement,
    analyze_image,
    fetch_fact_check_references,
    TruthLensDatabase,
    TruthLensEmbeddings
)
import os
from dotenv import load_dotenv
from config import GEMINI_API_KEY, FACTCHECK_API_KEY

# Load environment variables
load_dotenv()

app = FastAPI(title="TruthLens API", version="1.0.0")

# Add CORS middleware to allow React frontend to communicate with backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],  # React dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global variables to store initialized components
model = None
db = None
embeddings = None

@app.on_event("startup")
async def startup_event():
    """Initialize the AI model and database on startup"""
    global model, db, embeddings
    
    # Get API key from config
    api_key = GEMINI_API_KEY
    if not api_key:
        raise HTTPException(
            status_code=500, 
            detail="GEMINI_API_KEY not found in configuration"
        )
    
    try:
        # Initialize components
        model = configure_genai(api_key)
        db = TruthLensDatabase()
        embeddings = TruthLensEmbeddings()
        print("✅ TruthLens API initialized successfully!")
    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail=f"Failed to initialize TruthLens components: {str(e)}"
        )

class ClaimRequest(BaseModel):
    statement: str
    factcheck_api_key: str = None

class ClaimResponse(BaseModel):
    ai_analysis: dict
    fact_check: dict

@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "message": "TruthLens API",
        "version": "1.0.0",
        "endpoints": {
            "analyze_claim": "/analyze_claim/",
            "analyze_image": "/analyze_image/",
            "health": "/health/"
        }
    }

@app.get("/health/")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "model_loaded": model is not None,
        "database_loaded": db is not None,
        "embeddings_loaded": embeddings is not None
    }

@app.post("/analyze_claim/", response_model=ClaimResponse)
async def analyze_claim(data: ClaimRequest):
    """
    Analyze a text claim for misinformation
    
    Args:
        data: ClaimRequest containing statement and optional factcheck_api_key
        
    Returns:
        ClaimResponse with AI analysis and fact-check results
    """
    try:
        if not model or not db or not embeddings:
            raise HTTPException(
                status_code=500,
                detail="TruthLens components not initialized"
            )
        
        # Perform AI analysis
        ai_analysis = enhanced_analyze_statement(
            model, 
            data.statement, 
            db, 
            embeddings
        )
        
        # Perform fact-check if API key is provided
        fact_check = {}
        if data.factcheck_api_key:
            fact_check = fetch_fact_check_references(
                data.factcheck_api_key, 
                data.statement
            )
        else:
            fact_check = {
                "message": "Fact-check API key not provided",
                "claims": []
            }
        
        return ClaimResponse(
            ai_analysis=ai_analysis,
            fact_check=fact_check
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error analyzing claim: {str(e)}"
        )

@app.post("/analyze_image/")
async def analyze_image_endpoint(file: UploadFile = File(...)):
    """
    Analyze an uploaded image for misinformation
    
    Args:
        file: Uploaded image file
        
    Returns:
        Dictionary with image analysis results
    """
    try:
        if not model:
            raise HTTPException(
                status_code=500,
                detail="AI model not initialized"
            )
        
        # Validate file type
        if not file.content_type.startswith('image/'):
            raise HTTPException(
                status_code=400,
                detail="File must be an image"
            )
        
        # Read image bytes
        image_bytes = await file.read()
        
        # Validate file size (10MB limit)
        if len(image_bytes) > 10 * 1024 * 1024:
            raise HTTPException(
                status_code=400,
                detail="Image file too large. Maximum size is 10MB."
            )
        
        # Analyze image
        result = analyze_image(model, image_bytes)
        
        return {
            "filename": file.filename,
            "content_type": file.content_type,
            "file_size": len(image_bytes),
            "image_analysis": result
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error analyzing image: {str(e)}"
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
