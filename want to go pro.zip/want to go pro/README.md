# 🔍 TruthLens - AI-Powered Fact Checking

A comprehensive misinformation detection system that combines AI analysis with fact-checking APIs to help users identify potentially false or misleading content.

## 🏗️ Architecture

```
[ User ] ←→ [ React Frontend ] ←→ [ FastAPI Backend ] ←→ [ TruthLens Core ]
```

- **React Frontend**: Modern web interface for user interaction
- **FastAPI Backend**: REST API server handling requests
- **TruthLens Core**: Python logic for AI analysis and fact-checking

## ✨ Features

- **Text Analysis**: Analyze claims and statements for misinformation
- **Image Analysis**: Detect manipulated or misleading images
- **AI-Powered**: Uses Google Gemini AI for intelligent analysis
- **Fact-Check Integration**: Optional integration with Google Fact-Check API
- **Modern UI**: Beautiful, responsive React interface
- **Real-time Results**: Fast analysis with confidence scores

## 🚀 Quick Start

### Prerequisites

- Python 3.8+
- Node.js 16+
- npm or yarn
- Google Gemini API key

### 1. Backend Setup (FastAPI)

1. **Install Python dependencies:**
   ```bash
   pip install fastapi uvicorn google-generativeai requests pillow sentence-transformers fastembed pandas numpy python-dotenv
   ```

2. **Configure environment variables:**
   ```bash
   # Copy the example file
   cp env.example .env
   
   # Edit .env with your API keys
   GEMINI_API_KEY=your_actual_gemini_api_key_here
   FACTCHECK_API_KEY=your_actual_factcheck_api_key_here  # Optional
   ```

3. **Start the FastAPI server:**
   Make sure you are in the project's root directory (the one containing `truthlens_api.py`).

   ```bash
   uvicorn truthlens_api:app --reload --host 0.0.0.0 --port 8000
   ```

   The API will be available at `http://localhost:8000`.
   > **Note:** While the server binds to `0.0.0.0` (making it accessible on your local network), you should use `http://localhost:8000` to access it from your own machine.

### 2. Frontend Setup (React)

1. **Navigate to the React frontend directory:**
   ```bash
   cd react-frontend
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Configure environment variables (optional):**
   ```bash
   # Copy the example file
   cp env.example .env
   
   # Edit .env if you need to change the backend URL
   REACT_APP_BACKEND_URL=http://localhost:8000
   ```

4. **Start the React development server:**
   ```bash
   npm start
   ```

   The user interface will be available at: http://localhost:3000

## 📋 API Endpoints

### Backend API (FastAPI)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | API information and available endpoints |
| `/health/` | GET | Health check endpoint |
| `/analyze_claim/` | POST | Analyze text claims for misinformation |
| `/analyze_image/` | POST | Analyze uploaded images for manipulation |

### Example API Usage

**Analyze a claim:**
```bash
curl -X POST "http://localhost:8000/analyze_claim/" \
  -H "Content-Type: application/json" \
  -d '{
    "statement": "Vaccines cause autism",
    "factcheck_api_key": "your_factcheck_api_key"
  }'
```

**Analyze an image:**
```bash
curl -X POST "http://localhost:8000/analyze_image/" \
  -F "file=@path/to/your/image.jpg"
```

## 🔧 Configuration

### Environment Variables

**Backend (.env):**
- `GEMINI_API_KEY`: Your Google Gemini API key (required)
- `FACTCHECK_API_KEY`: Google Fact-Check API key (optional)

**Frontend (.env):**
- `REACT_APP_BACKEND_URL`: Backend API URL (default: http://localhost:8000)

### Getting API Keys

1. **Google Gemini API Key:**
   - Visit: https://makersuite.google.com/app/apikey
   - Create a new API key
   - Copy and add to your `.env` file

2. **Google Fact-Check API Key (Optional):**
   - Visit: https://developers.google.com/fact-check/tools/api
   - Enable the Fact Check API
   - Create credentials and copy to your `.env` file

## 🎯 Usage

### Using the Web Interface

1. **Open your browser** and go to http://localhost:3000
2. **Analyze Text Claims:**
   - Enter a claim or statement in the text area
   - Optionally add your Fact-Check API key
   - Click "Check Truth" to analyze
   - View AI analysis results and confidence scores

3. **Analyze Images:**
   - Click "Choose an image file" or drag and drop
   - Select an image (PNG, JPG, JPEG, GIF, WEBP)
   - Click "Analyze Image" to process
   - View AI-powered image analysis results

### Using the API Directly

The FastAPI backend provides RESTful endpoints that can be consumed by any HTTP client or integrated into other applications.

## 📁 Project Structure

```
truthlens-project/
├── gen_ai/                    # Core TruthLens logic
│   ├── TruthLens.py          # Main TruthLens implementation
│   └── ui.py                 # Streamlit UI (legacy)
├── react-frontend/           # React frontend application
│   ├── src/
│   │   ├── components/       # React components
│   │   │   ├── AnalyzeClaimForm.js
│   │   │   └── AnalyzeImageForm.js
│   │   ├── App.js           # Main React app
│   │   └── index.js         # React entry point
│   ├── public/              # Static assets
│   └── package.json         # Node.js dependencies
├── truthlens_api.py         # FastAPI backend
├── env.example              # Environment variables template
└── README.md               # This file
```

## 🛠️ Development

### Running in Development Mode

1. **Backend (FastAPI):**
   ```bash
   uvicorn truthlens_api:app --reload
   ```

2. **Frontend (React):**
   ```bash
   cd react-frontend
   npm start
   ```

### Building for Production

1. **Build React frontend:**
   ```bash
   cd react-frontend
   npm run build
   ```

2. **Serve FastAPI with production server:**
   ```bash
   uvicorn truthlens_api:app --host 0.0.0.0 --port 8000
   ```

## 🔍 How It Works

1. **User Input**: User enters text or uploads image via React frontend
2. **API Request**: Frontend sends HTTP request to FastAPI backend
3. **AI Analysis**: Backend uses TruthLens core logic with Google Gemini AI
4. **Fact-Checking**: Optional integration with Google Fact-Check API
5. **Results**: Combined analysis results returned to frontend
6. **Display**: Frontend presents results with confidence scores and explanations

## 🚨 Troubleshooting

### Common Issues

1. **"API key not configured" error:**
   - Ensure your `.env` file exists and contains valid API keys
   - Check that the API key format is correct (no extra spaces)

2. **CORS errors in browser:**
   - The FastAPI backend includes CORS middleware
   - Ensure both frontend and backend are running on correct ports

3. **Image upload fails:**
   - Check file size (max 10MB)
   - Ensure file type is supported (PNG, JPG, JPEG, GIF, WEBP)

4. **Backend connection failed:**
   - Verify FastAPI server is running on http://localhost:8000
   - Check console for any error messages

### Logs and Debugging

- **FastAPI logs**: Check terminal where you started the backend
- **React logs**: Check browser developer console
- **Network requests**: Use browser dev tools to inspect API calls

## 📚 Additional Resources

- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [React Documentation](https://reactjs.org/docs)
- [Google Gemini API](https://ai.google.dev/)
- [Google Fact-Check API](https://developers.google.com/fact-check/tools/api)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

If you encounter any issues or have questions:

1. Check the troubleshooting section above
2. Review the API documentation
3. Create an issue in the repository
4. Check the logs for error messages

---

**Happy fact-checking! 🔍✨**
